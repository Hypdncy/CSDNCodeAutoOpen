$(function () {
    $(".hide-preCode-box").css("display", "none");
});